package user;

import java.sql.Timestamp;

public class UserVO {
	
	private int user_num;
	private String user_id;
	private String user_sex;
	private String user_mil_mil;
	private String user_mil_type;
	private String user_mil_rnk;
	private String user_stu;
	private String user_mid_name;
	private String user_mid_area;
	private String user_mid_sdate;
	private String user_mid_edate;
	private String user_mid_grad;
	private String user_high_name;
	private String user_high_area;
	private String user_high_GED;
	private String user_high_Gdate;
	private String user_high_sdate;
	private String user_high_edate;
	private String user_high_trans;
	private String user_high_grad;
	private String user_high_major;
	private String user_univ_type1;
	private String user_univ_name1;
	private String user_univ_area1;
	private String user_univ_sdate1;
	private String user_univ_edate1;
	private String user_univ_grad1;
	private String user_univ_major1;
	private String user_univ_nm1;
	private float user_univ_cdit1;
	private String user_univ_type2;
	private String user_univ_name2;
	private String user_univ_area2;
	private String user_univ_sdate2;
	private String user_univ_edate2;
	private String user_univ_grad2;
	private String user_univ_major2;
	private String user_univ_nm2;
	private float user_univ_cdit2;
	private String user_univ_type3;
	private String user_univ_name3;
	private String user_univ_area3;
	private String user_univ_sdate3;
	private String user_univ_edate3;
	private String user_univ_grad3;
	private String user_univ_major3;
	private String user_univ_nm3;
	private float user_univ_cdit3;
	private String user_caeer;
	private String user_caeer_name1;
	private String user_caeer_sdate1;
	private String user_caeer_edate1;
	private String user_caeer_leave1;
	private String user_caeer_jobt1;
	private String user_caeer_dept1;
	private String user_caeer_linc1;
	private String user_caeer_area1;
	private String user_caeer_sale1;
	private String user_caeer_name2;
	private String user_caeer_sdate2;
	private String user_caeer_edate2;
	private String user_caeer_leave2;
	private String user_caeer_jobt2;
	private String user_caeer_dept2;
	private String user_caeer_linc2;
	private String user_caeer_area2;
	private String user_caeer_sale2;
	private String user_caeer_name3;
	private String user_caeer_sdate3;
	private String user_caeer_edate3;
	private String user_caeer_leave3;
	private String user_caeer_jobt3;
	private String user_caeer_dept3;
	private String user_caeer_linc3;
	private String user_caeer_area3;
	private String user_caeer_sale3;
	private String user_caeer_name4;
	private String user_caeer_sdate4;
	private String user_caeer_edate4;
	private String user_caeer_leave4;
	private String user_caeer_jobt4;
	private String user_caeer_dept4;
	private String user_caeer_linc4;
	private String user_caeer_area4;
	private String user_caeer_sale4;
	private String user_licen_type1;
	private String user_licen_name1;
	private String user_licen_publ1;
	private String user_licen_pass1;
	private String user_licen_date1;
	private String user_licen_type2;
	private String user_licen_name2;
	private String user_licen_publ2;
	private String user_licen_pass2;
	private String user_licen_date2;
	private String user_licen_type3;
	private String user_licen_name3;
	private String user_licen_publ3;
	private String user_licen_pass3;
	private String user_licen_date3;
	private String reg_date;
	public int getUser_num() {
		return user_num;
	}
	public void setUser_num(int user_num) {
		this.user_num = user_num;
	}
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getUser_sex() {
		return user_sex;
	}
	public void setUser_sex(String user_sex) {
		this.user_sex = user_sex;
	}
	public String getUser_mil_mil() {
		return user_mil_mil;
	}
	public void setUser_mil_mil(String user_mil_mil) {
		this.user_mil_mil = user_mil_mil;
	}
	public String getUser_mil_type() {
		return user_mil_type;
	}
	public void setUser_mil_type(String user_mil_type) {
		this.user_mil_type = user_mil_type;
	}
	public String getUser_mil_rnk() {
		return user_mil_rnk;
	}
	public void setUser_mil_rnk(String user_mil_rnk) {
		this.user_mil_rnk = user_mil_rnk;
	}
	public String getUser_stu() {
		return user_stu;
	}
	public void setUser_stu(String user_stu) {
		this.user_stu = user_stu;
	}
	public String getUser_mid_name() {
		return user_mid_name;
	}
	public void setUser_mid_name(String user_mid_name) {
		this.user_mid_name = user_mid_name;
	}
	public String getUser_mid_area() {
		return user_mid_area;
	}
	public void setUser_mid_area(String user_mid_area) {
		this.user_mid_area = user_mid_area;
	}
	public String getUser_mid_sdate() {
		return user_mid_sdate;
	}
	public void setUser_mid_sdate(String user_mid_sdate) {
		this.user_mid_sdate = user_mid_sdate;
	}
	public String getUser_mid_edate() {
		return user_mid_edate;
	}
	public void setUser_mid_edate(String user_mid_edate) {
		this.user_mid_edate = user_mid_edate;
	}
	public String getUser_mid_grad() {
		return user_mid_grad;
	}
	public void setUser_mid_grad(String user_mid_grad) {
		this.user_mid_grad = user_mid_grad;
	}
	public String getUser_high_name() {
		return user_high_name;
	}
	public void setUser_high_name(String user_high_name) {
		this.user_high_name = user_high_name;
	}
	public String getUser_high_area() {
		return user_high_area;
	}
	public void setUser_high_area(String user_high_area) {
		this.user_high_area = user_high_area;
	}
	public String getUser_high_GED() {
		return user_high_GED;
	}
	public void setUser_high_GED(String user_high_GED) {
		this.user_high_GED = user_high_GED;
	}
	public String getUser_high_Gdate() {
		return user_high_Gdate;
	}
	public void setUser_high_Gdate(String user_high_Gdate) {
		this.user_high_Gdate = user_high_Gdate;
	}
	public String getUser_high_sdate() {
		return user_high_sdate;
	}
	public void setUser_high_sdate(String user_high_sdate) {
		this.user_high_sdate = user_high_sdate;
	}
	public String getUser_high_edate() {
		return user_high_edate;
	}
	public void setUser_high_edate(String user_high_edate) {
		this.user_high_edate = user_high_edate;
	}
	public String getUser_high_trans() {
		return user_high_trans;
	}
	public void setUser_high_trans(String user_high_trans) {
		this.user_high_trans = user_high_trans;
	}
	public String getUser_high_grad() {
		return user_high_grad;
	}
	public void setUser_high_grad(String user_high_grad) {
		this.user_high_grad = user_high_grad;
	}
	public String getUser_high_major() {
		return user_high_major;
	}
	public void setUser_high_major(String user_high_major) {
		this.user_high_major = user_high_major;
	}
	public String getUser_univ_type1() {
		return user_univ_type1;
	}
	public void setUser_univ_type1(String user_univ_type1) {
		this.user_univ_type1 = user_univ_type1;
	}
	public String getUser_univ_name1() {
		return user_univ_name1;
	}
	public void setUser_univ_name1(String user_univ_name1) {
		this.user_univ_name1 = user_univ_name1;
	}
	public String getUser_univ_area1() {
		return user_univ_area1;
	}
	public void setUser_univ_area1(String user_univ_area1) {
		this.user_univ_area1 = user_univ_area1;
	}
	public String getUser_univ_sdate1() {
		return user_univ_sdate1;
	}
	public void setUser_univ_sdate1(String user_univ_sdate1) {
		this.user_univ_sdate1 = user_univ_sdate1;
	}
	public String getUser_univ_edate1() {
		return user_univ_edate1;
	}
	public void setUser_univ_edate1(String user_univ_edate1) {
		this.user_univ_edate1 = user_univ_edate1;
	}
	public String getUser_univ_grad1() {
		return user_univ_grad1;
	}
	public void setUser_univ_grad1(String user_univ_grad1) {
		this.user_univ_grad1 = user_univ_grad1;
	}
	public String getUser_univ_major1() {
		return user_univ_major1;
	}
	public void setUser_univ_major1(String user_univ_major1) {
		this.user_univ_major1 = user_univ_major1;
	}
	public String getUser_univ_nm1() {
		return user_univ_nm1;
	}
	public void setUser_univ_nm1(String user_univ_nm1) {
		this.user_univ_nm1 = user_univ_nm1;
	}
	public float getUser_univ_cdit1() {
		return user_univ_cdit1;
	}
	public void setUser_univ_cdit1(float user_univ_cdit1) {
		this.user_univ_cdit1 = user_univ_cdit1;
	}
	public String getUser_univ_type2() {
		return user_univ_type2;
	}
	public void setUser_univ_type2(String user_univ_type2) {
		this.user_univ_type2 = user_univ_type2;
	}
	public String getUser_univ_name2() {
		return user_univ_name2;
	}
	public void setUser_univ_name2(String user_univ_name2) {
		this.user_univ_name2 = user_univ_name2;
	}
	public String getUser_univ_area2() {
		return user_univ_area2;
	}
	public void setUser_univ_area2(String user_univ_area2) {
		this.user_univ_area2 = user_univ_area2;
	}
	public String getUser_univ_sdate2() {
		return user_univ_sdate2;
	}
	public void setUser_univ_sdate2(String user_univ_sdate2) {
		this.user_univ_sdate2 = user_univ_sdate2;
	}
	public String getUser_univ_edate2() {
		return user_univ_edate2;
	}
	public void setUser_univ_edate2(String user_univ_edate2) {
		this.user_univ_edate2 = user_univ_edate2;
	}
	public String getUser_univ_grad2() {
		return user_univ_grad2;
	}
	public void setUser_univ_grad2(String user_univ_grad2) {
		this.user_univ_grad2 = user_univ_grad2;
	}
	public String getUser_univ_major2() {
		return user_univ_major2;
	}
	public void setUser_univ_major2(String user_univ_major2) {
		this.user_univ_major2 = user_univ_major2;
	}
	public String getUser_univ_nm2() {
		return user_univ_nm2;
	}
	public void setUser_univ_nm2(String user_univ_nm2) {
		this.user_univ_nm2 = user_univ_nm2;
	}
	public float getUser_univ_cdit2() {
		return user_univ_cdit2;
	}
	public void setUser_univ_cdit2(float user_univ_cdit2) {
		this.user_univ_cdit2 = user_univ_cdit2;
	}
	public String getUser_univ_type3() {
		return user_univ_type3;
	}
	public void setUser_univ_type3(String user_univ_type3) {
		this.user_univ_type3 = user_univ_type3;
	}
	public String getUser_univ_name3() {
		return user_univ_name3;
	}
	public void setUser_univ_name3(String user_univ_name3) {
		this.user_univ_name3 = user_univ_name3;
	}
	public String getUser_univ_area3() {
		return user_univ_area3;
	}
	public void setUser_univ_area3(String user_univ_area3) {
		this.user_univ_area3 = user_univ_area3;
	}
	public String getUser_univ_sdate3() {
		return user_univ_sdate3;
	}
	public void setUser_univ_sdate3(String user_univ_sdate3) {
		this.user_univ_sdate3 = user_univ_sdate3;
	}
	public String getUser_univ_edate3() {
		return user_univ_edate3;
	}
	public void setUser_univ_edate3(String user_univ_edate3) {
		this.user_univ_edate3 = user_univ_edate3;
	}
	public String getUser_univ_grad3() {
		return user_univ_grad3;
	}
	public void setUser_univ_grad3(String user_univ_grad3) {
		this.user_univ_grad3 = user_univ_grad3;
	}
	public String getUser_univ_major3() {
		return user_univ_major3;
	}
	public void setUser_univ_major3(String user_univ_major3) {
		this.user_univ_major3 = user_univ_major3;
	}
	public String getUser_univ_nm3() {
		return user_univ_nm3;
	}
	public void setUser_univ_nm3(String user_univ_nm3) {
		this.user_univ_nm3 = user_univ_nm3;
	}
	public float getUser_univ_cdit3() {
		return user_univ_cdit3;
	}
	public void setUser_univ_cdit3(float user_univ_cdit3) {
		this.user_univ_cdit3 = user_univ_cdit3;
	}
	public String getUser_caeer() {
		return user_caeer;
	}
	public void setUser_caeer(String user_caeer) {
		this.user_caeer = user_caeer;
	}
	public String getUser_caeer_name1() {
		return user_caeer_name1;
	}
	public void setUser_caeer_name1(String user_caeer_name1) {
		this.user_caeer_name1 = user_caeer_name1;
	}
	public String getUser_caeer_sdate1() {
		return user_caeer_sdate1;
	}
	public void setUser_caeer_sdate1(String user_caeer_sdate1) {
		this.user_caeer_sdate1 = user_caeer_sdate1;
	}
	public String getUser_caeer_edate1() {
		return user_caeer_edate1;
	}
	public void setUser_caeer_edate1(String user_caeer_edate1) {
		this.user_caeer_edate1 = user_caeer_edate1;
	}
	public String getUser_caeer_leave1() {
		return user_caeer_leave1;
	}
	public void setUser_caeer_leave1(String user_caeer_leave1) {
		this.user_caeer_leave1 = user_caeer_leave1;
	}
	public String getUser_caeer_jobt1() {
		return user_caeer_jobt1;
	}
	public void setUser_caeer_jobt1(String user_caeer_jobt1) {
		this.user_caeer_jobt1 = user_caeer_jobt1;
	}
	public String getUser_caeer_dept1() {
		return user_caeer_dept1;
	}
	public void setUser_caeer_dept1(String user_caeer_dept1) {
		this.user_caeer_dept1 = user_caeer_dept1;
	}
	public String getUser_caeer_linc1() {
		return user_caeer_linc1;
	}
	public void setUser_caeer_linc1(String user_caeer_linc1) {
		this.user_caeer_linc1 = user_caeer_linc1;
	}
	public String getUser_caeer_area1() {
		return user_caeer_area1;
	}
	public void setUser_caeer_area1(String user_caeer_area1) {
		this.user_caeer_area1 = user_caeer_area1;
	}
	public String getUser_caeer_sale1() {
		return user_caeer_sale1;
	}
	public void setUser_caeer_sale1(String user_caeer_sale1) {
		this.user_caeer_sale1 = user_caeer_sale1;
	}
	public String getUser_caeer_name2() {
		return user_caeer_name2;
	}
	public void setUser_caeer_name2(String user_caeer_name2) {
		this.user_caeer_name2 = user_caeer_name2;
	}
	public String getUser_caeer_sdate2() {
		return user_caeer_sdate2;
	}
	public void setUser_caeer_sdate2(String user_caeer_sdate2) {
		this.user_caeer_sdate2 = user_caeer_sdate2;
	}
	public String getUser_caeer_edate2() {
		return user_caeer_edate2;
	}
	public void setUser_caeer_edate2(String user_caeer_edate2) {
		this.user_caeer_edate2 = user_caeer_edate2;
	}
	public String getUser_caeer_leave2() {
		return user_caeer_leave2;
	}
	public void setUser_caeer_leave2(String user_caeer_leave2) {
		this.user_caeer_leave2 = user_caeer_leave2;
	}
	public String getUser_caeer_jobt2() {
		return user_caeer_jobt2;
	}
	public void setUser_caeer_jobt2(String user_caeer_jobt2) {
		this.user_caeer_jobt2 = user_caeer_jobt2;
	}
	public String getUser_caeer_dept2() {
		return user_caeer_dept2;
	}
	public void setUser_caeer_dept2(String user_caeer_dept2) {
		this.user_caeer_dept2 = user_caeer_dept2;
	}
	public String getUser_caeer_linc2() {
		return user_caeer_linc2;
	}
	public void setUser_caeer_linc2(String user_caeer_linc2) {
		this.user_caeer_linc2 = user_caeer_linc2;
	}
	public String getUser_caeer_area2() {
		return user_caeer_area2;
	}
	public void setUser_caeer_area2(String user_caeer_area2) {
		this.user_caeer_area2 = user_caeer_area2;
	}
	public String getUser_caeer_sale2() {
		return user_caeer_sale2;
	}
	public void setUser_caeer_sale2(String user_caeer_sale2) {
		this.user_caeer_sale2 = user_caeer_sale2;
	}
	public String getUser_caeer_name3() {
		return user_caeer_name3;
	}
	public void setUser_caeer_name3(String user_caeer_name3) {
		this.user_caeer_name3 = user_caeer_name3;
	}
	public String getUser_caeer_sdate3() {
		return user_caeer_sdate3;
	}
	public void setUser_caeer_sdate3(String user_caeer_sdate3) {
		this.user_caeer_sdate3 = user_caeer_sdate3;
	}
	public String getUser_caeer_edate3() {
		return user_caeer_edate3;
	}
	public void setUser_caeer_edate3(String user_caeer_edate3) {
		this.user_caeer_edate3 = user_caeer_edate3;
	}
	public String getUser_caeer_leave3() {
		return user_caeer_leave3;
	}
	public void setUser_caeer_leave3(String user_caeer_leave3) {
		this.user_caeer_leave3 = user_caeer_leave3;
	}
	public String getUser_caeer_jobt3() {
		return user_caeer_jobt3;
	}
	public void setUser_caeer_jobt3(String user_caeer_jobt3) {
		this.user_caeer_jobt3 = user_caeer_jobt3;
	}
	public String getUser_caeer_dept3() {
		return user_caeer_dept3;
	}
	public void setUser_caeer_dept3(String user_caeer_dept3) {
		this.user_caeer_dept3 = user_caeer_dept3;
	}
	public String getUser_caeer_linc3() {
		return user_caeer_linc3;
	}
	public void setUser_caeer_linc3(String user_caeer_linc3) {
		this.user_caeer_linc3 = user_caeer_linc3;
	}
	public String getUser_caeer_area3() {
		return user_caeer_area3;
	}
	public void setUser_caeer_area3(String user_caeer_area3) {
		this.user_caeer_area3 = user_caeer_area3;
	}
	public String getUser_caeer_sale3() {
		return user_caeer_sale3;
	}
	public void setUser_caeer_sale3(String user_caeer_sale3) {
		this.user_caeer_sale3 = user_caeer_sale3;
	}
	public String getUser_caeer_name4() {
		return user_caeer_name4;
	}
	public void setUser_caeer_name4(String user_caeer_name4) {
		this.user_caeer_name4 = user_caeer_name4;
	}
	public String getUser_caeer_sdate4() {
		return user_caeer_sdate4;
	}
	public void setUser_caeer_sdate4(String user_caeer_sdate4) {
		this.user_caeer_sdate4 = user_caeer_sdate4;
	}
	public String getUser_caeer_edate4() {
		return user_caeer_edate4;
	}
	public void setUser_caeer_edate4(String user_caeer_edate4) {
		this.user_caeer_edate4 = user_caeer_edate4;
	}
	public String getUser_caeer_leave4() {
		return user_caeer_leave4;
	}
	public void setUser_caeer_leave4(String user_caeer_leave4) {
		this.user_caeer_leave4 = user_caeer_leave4;
	}
	public String getUser_caeer_jobt4() {
		return user_caeer_jobt4;
	}
	public void setUser_caeer_jobt4(String user_caeer_jobt4) {
		this.user_caeer_jobt4 = user_caeer_jobt4;
	}
	public String getUser_caeer_dept4() {
		return user_caeer_dept4;
	}
	public void setUser_caeer_dept4(String user_caeer_dept4) {
		this.user_caeer_dept4 = user_caeer_dept4;
	}
	public String getUser_caeer_linc4() {
		return user_caeer_linc4;
	}
	public void setUser_caeer_linc4(String user_caeer_linc4) {
		this.user_caeer_linc4 = user_caeer_linc4;
	}
	public String getUser_caeer_area4() {
		return user_caeer_area4;
	}
	public void setUser_caeer_area4(String user_caeer_area4) {
		this.user_caeer_area4 = user_caeer_area4;
	}
	public String getUser_caeer_sale4() {
		return user_caeer_sale4;
	}
	public void setUser_caeer_sale4(String user_caeer_sale4) {
		this.user_caeer_sale4 = user_caeer_sale4;
	}
	public String getUser_licen_type1() {
		return user_licen_type1;
	}
	public void setUser_licen_type1(String user_licen_type1) {
		this.user_licen_type1 = user_licen_type1;
	}
	public String getUser_licen_name1() {
		return user_licen_name1;
	}
	public void setUser_licen_name1(String user_licen_name1) {
		this.user_licen_name1 = user_licen_name1;
	}
	public String getUser_licen_publ1() {
		return user_licen_publ1;
	}
	public void setUser_licen_publ1(String user_licen_publ1) {
		this.user_licen_publ1 = user_licen_publ1;
	}
	public String getUser_licen_pass1() {
		return user_licen_pass1;
	}
	public void setUser_licen_pass1(String user_licen_pass1) {
		this.user_licen_pass1 = user_licen_pass1;
	}
	public String getUser_licen_date1() {
		return user_licen_date1;
	}
	public void setUser_licen_date1(String user_licen_date1) {
		this.user_licen_date1 = user_licen_date1;
	}
	public String getUser_licen_type2() {
		return user_licen_type2;
	}
	public void setUser_licen_type2(String user_licen_type2) {
		this.user_licen_type2 = user_licen_type2;
	}
	public String getUser_licen_name2() {
		return user_licen_name2;
	}
	public void setUser_licen_name2(String user_licen_name2) {
		this.user_licen_name2 = user_licen_name2;
	}
	public String getUser_licen_publ2() {
		return user_licen_publ2;
	}
	public void setUser_licen_publ2(String user_licen_publ2) {
		this.user_licen_publ2 = user_licen_publ2;
	}
	public String getUser_licen_pass2() {
		return user_licen_pass2;
	}
	public void setUser_licen_pass2(String user_licen_pass2) {
		this.user_licen_pass2 = user_licen_pass2;
	}
	public String getUser_licen_date2() {
		return user_licen_date2;
	}
	public void setUser_licen_date2(String user_licen_date2) {
		this.user_licen_date2 = user_licen_date2;
	}
	public String getUser_licen_type3() {
		return user_licen_type3;
	}
	public void setUser_licen_type3(String user_licen_type3) {
		this.user_licen_type3 = user_licen_type3;
	}
	public String getUser_licen_name3() {
		return user_licen_name3;
	}
	public void setUser_licen_name3(String user_licen_name3) {
		this.user_licen_name3 = user_licen_name3;
	}
	public String getUser_licen_publ3() {
		return user_licen_publ3;
	}
	public void setUser_licen_publ3(String user_licen_publ3) {
		this.user_licen_publ3 = user_licen_publ3;
	}
	public String getUser_licen_pass3() {
		return user_licen_pass3;
	}
	public void setUser_licen_pass3(String user_licen_pass3) {
		this.user_licen_pass3 = user_licen_pass3;
	}
	public String getUser_licen_date3() {
		return user_licen_date3;
	}
	public void setUser_licen_date3(String user_licen_date3) {
		this.user_licen_date3 = user_licen_date3;
	}
	public String getReg_date() {
		return reg_date;
	}
	public void setReg_date(String reg_date) {
		this.reg_date = reg_date;
	}

}
